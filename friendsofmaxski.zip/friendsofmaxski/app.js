(function () {
  var MAX_PER_ROOM = 4, MAX_AIRPORTS = 3, MAX_ROOMS = 5;

  var AIRPORTS = [
    { id: 'lba', name: 'Leeds Bradford', top: true },
    { id: 'man', name: 'Manchester', top: true },
    { id: 'ncl', name: 'Newcastle', top: true },
    { id: 'bhx', name: 'Birmingham' },
    { id: 'brs', name: 'Bristol' },
    { id: 'ema', name: 'East Midlands' },
    { id: 'edi', name: 'Edinburgh' },
    { id: 'gla', name: 'Glasgow' },
    { id: 'lpl', name: 'Liverpool' },
    { id: 'lgw', name: 'London Gatwick' },
    { id: 'lhr', name: 'London Heathrow' },
    { id: 'ltn', name: 'London Luton' },
    { id: 'stn', name: 'London Stansted' }
  ];

  function freshRooms() {
    var r = [];
    for (var i = 0; i < MAX_ROOMS; i++) r.push({ adults: 2, children: [] });
    return r;
  }

  var state = { rooms: freshRooms(), roomCount: 1, airports: [], showAgeErrors: false };

  function $(id) { return document.getElementById(id); }
  function h(tag, attrs) {
    var el = document.createElement(tag);
    if (attrs) Object.keys(attrs).forEach(function (k) {
      var v = attrs[k];
      if (v === false || v == null) return;
      if (k === 'text') el.textContent = v;
      else if (k === 'class') el.className = v;
      else if (k === 'on') Object.keys(v).forEach(function (ev) { el.addEventListener(ev, v[ev]); });
      else if (v === true) el.setAttribute(k, '');
      else el.setAttribute(k, v);
    });
    for (var i = 2; i < arguments.length; i++) {
      var c = arguments[i];
      if (c == null || c === false) continue;
      el.appendChild(typeof c === 'string' ? document.createTextNode(c) : c);
    }
    return el;
  }
  function plural(n, one, many) { return n + ' ' + (n === 1 ? one : many); }
  function setError(id, msg, field) {
    var el = $(id);
    el.textContent = msg || '';
    el.hidden = !msg;
    if (field) { if (msg) field.setAttribute('aria-invalid', 'true'); else field.removeAttribute('aria-invalid'); }
  }
  function dateLabel() {
    var s = $('travel-date');
    return s.value ? s.options[s.selectedIndex].text : '';
  }
  function ageLabel(a) { return a === 0 ? 'under 1' : String(a); }

  /* ---------- airports ---------- */
  function buildAirports() {
    AIRPORTS.forEach(function (a) {
      var input = h('input', { type: 'checkbox', id: 'airport-' + a.id, value: a.id, on: { change: onAirport } });
      var chip = h('label', { class: 'chip' }, input, h('span', { text: a.name }));
      $(a.top ? 'airports-top' : 'airports-more').appendChild(chip);
    });
  }
  function onAirport() {
    state.airports = AIRPORTS.filter(function (a) { return $('airport-' + a.id).checked; }).map(function (a) { return a.id; });
    syncAirports();
    if (state.airports.length) setError('err-airports', '');
  }
  function syncAirports() {
    var full = state.airports.length >= MAX_AIRPORTS;
    AIRPORTS.forEach(function (a) {
      var box = $('airport-' + a.id);
      box.checked = state.airports.indexOf(a.id) > -1;
      box.disabled = full && !box.checked;
    });
    var n = state.airports.length;
    $('airport-hint').textContent = n === 0 ? 'Pick up to three.'
      : full ? '3 of 3 chosen. Untick one to swap.'
      : n + ' of 3 chosen.';
  }
  function showMoreAirports() {
    $('airports-more').hidden = false;
    $('more-airports').hidden = true;
    $('more-airports').setAttribute('aria-expanded', 'true');
    var first = $('airports-more').querySelector('input:not(:disabled)');
    if (first) first.focus();
  }

  /* ---------- rooms ---------- */
  function roomEl(i) {
    var room = state.rooms[i], n = i + 1;
    var total = room.adults + room.children.length;
    var full = total >= MAX_PER_ROOM;

    function stepper(kind, value, canMinus, canPlus, noun) {
      return h('div', { class: 'stepper' },
        h('button', { type: 'button', id: 'room-' + n + '-' + kind + '-minus', disabled: !canMinus,
          'aria-label': 'Remove ' + noun + ' from room ' + n, text: '−',
          on: { click: function () { change(i, kind, -1); } } }),
        h('output', { id: 'room-' + n + '-' + kind, text: String(value) }),
        h('button', { type: 'button', id: 'room-' + n + '-' + kind + '-plus', disabled: !canPlus,
          'aria-label': 'Add ' + noun + ' to room ' + n, text: '+',
          on: { click: function () { change(i, kind, 1); } } })
      );
    }

    var el = h('div', { class: 'room', id: 'room-' + n, role: 'group', 'aria-label': 'Room ' + n },
      h('div', { class: 'room-head' },
        h('h3', { class: 'room-name', text: 'Room ' + n }),
        h('span', { class: 'room-count', text: total + ' of ' + MAX_PER_ROOM + (full ? ', room full' : ' people') })
      ),
      h('div', { class: 'row' },
        h('span', { class: 'row-label' }, 'Adults', h('small', { text: '18 and over' })),
        stepper('adults', room.adults, room.adults > 1, !full, 'an adult')
      ),
      h('div', { class: 'row' },
        h('span', { class: 'row-label' }, 'Children', h('small', { text: '17 and under' })),
        stepper('children', room.children.length, room.children.length > 0, !full, 'a child')
      )
    );

    if (room.children.length) {
      var missing = false;
      var grid = h('div', { class: 'age-grid' });
      room.children.forEach(function (age, c) {
        var id = 'room-' + n + '-child-' + (c + 1) + '-age';
        var sel = h('select', { id: id, on: { change: function (e) {
          room.children[c] = e.target.value === '' ? null : Number(e.target.value);
          renderRooms();
        } } });
        sel.appendChild(h('option', { value: '', text: 'Age' }));
        sel.appendChild(h('option', { value: '0', text: 'Under 1' }));
        for (var a = 1; a <= 17; a++) sel.appendChild(h('option', { value: String(a), text: String(a) }));
        sel.value = age == null ? '' : String(age);
        if (age == null && state.showAgeErrors) { sel.setAttribute('aria-invalid', 'true'); missing = true; }
        grid.appendChild(h('div', null, h('label', { for: id, text: 'Child ' + (c + 1) }), sel));
      });
      var when = dateLabel();
      el.appendChild(h('div', { class: 'ages' },
        h('p', { class: 'hint', text: 'Age on the day you travel' + (when ? ', ' + when : '') + '.' }),
        grid,
        missing ? h('p', { class: 'error', role: 'alert', text: 'Choose an age for each child in room ' + n + '.' }) : null
      ));
    }
    return el;
  }

  function change(i, kind, delta) {
    var room = state.rooms[i];
    var total = room.adults + room.children.length;
    if (delta > 0 && total >= MAX_PER_ROOM) return;
    if (kind === 'adults') {
      if (room.adults + delta < 1) return;
      room.adults += delta;
    } else if (delta > 0) {
      room.children.push(null);
    } else if (room.children.length) {
      room.children.pop();
    }
    renderRooms();
  }

  function renderRooms() {
    var activeId = document.activeElement && document.activeElement.id;
    var host = $('rooms');
    host.textContent = '';
    for (var i = 0; i < state.roomCount; i++) host.appendChild(roomEl(i));

    var adults = 0, kids = 0;
    for (var j = 0; j < state.roomCount; j++) { adults += state.rooms[j].adults; kids += state.rooms[j].children.length; }
    $('total').textContent = plural(adults + kids, 'person', 'people') + ' in ' + plural(state.roomCount, 'bedroom', 'bedrooms') +
      ': ' + plural(adults, 'adult', 'adults') + (kids ? ' and ' + plural(kids, 'child', 'children') : '') + '.';

    if (activeId && activeId.indexOf('room-') === 0) {
      var back = $(activeId);
      if (back && back.disabled) back = back.parentNode.querySelector('button:not(:disabled)');
      if (back) back.focus();
    }
  }

  /* ---------- submit ---------- */
  function validate() {
    var first = null;
    function fail(el) { if (!first) first = el; }

    var date = $('travel-date');
    if (!date.value) { setError('err-date', 'Choose a travel date.', date); fail(date); } else setError('err-date', '', date);

    if (!state.airports.length) { setError('err-airports', 'Pick at least one airport.'); fail($('airport-lba')); } else setError('err-airports', '');

    state.showAgeErrors = true;
    renderRooms();
    var badAge = $('rooms').querySelector('select[aria-invalid="true"]');
    if (badAge) fail(badAge);

    var name = $('lead-name');
    if (!name.value.trim()) { setError('err-name', 'Tell us your name.', name); fail(name); } else setError('err-name', '', name);

    var email = $('lead-email');
    var ok = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(email.value.trim());
    if (!ok) { setError('err-email', 'Enter an email address, like name@example.com.', email); fail(email); } else setError('err-email', '', email);

    return first;
  }

  function summaryRow(term, lines) {
    var dd = h('dd');
    lines.forEach(function (l) { dd.appendChild(h('span', { text: l })); });
    return h('div', null, h('dt', { text: term }), dd);
  }

  function showDone() {
    var name = $('lead-name').value.trim();
    var email = $('lead-email').value.trim();
    $('done-title').textContent = 'Thanks, ' + name.split(/\s+/)[0] + '. We have your details.';
    $('done-lead').textContent = 'We will send your quote to ' + email + '.';

    var airports = AIRPORTS.filter(function (a) { return state.airports.indexOf(a.id) > -1; }).map(function (a) { return a.name; });
    var roomLines = [];
    for (var i = 0; i < state.roomCount; i++) {
      var r = state.rooms[i];
      var line = 'Room ' + (i + 1) + ': ' + plural(r.adults, 'adult', 'adults');
      if (r.children.length) {
        line += ', ' + plural(r.children.length, 'child', 'children') + ' (aged ' + r.children.map(ageLabel).join(', ') + ')';
      }
      roomLines.push(line);
    }
    var s = $('summary');
    s.textContent = '';
    s.appendChild(summaryRow('Travel date', [dateLabel()]));
    s.appendChild(summaryRow('Airports', [airports.join(', ')]));
    s.appendChild(summaryRow('Bedrooms', [String(state.roomCount)]));
    s.appendChild(summaryRow('Travellers', roomLines));
    s.appendChild(summaryRow('Name', [name]));
    s.appendChild(summaryRow('Email', [email]));

    $('quote-form').hidden = true;
    $('hero-copy').hidden = true;
    $('done').hidden = false;
    window.scrollTo(0, 0);
    $('done-title').focus();
  }

  function showForm() {
    $('done').hidden = true;
    $('quote-form').hidden = false;
    $('hero-copy').hidden = false;
    window.scrollTo(0, 0);
  }

  function reset() {
    state = { rooms: freshRooms(), roomCount: 1, airports: [], showAgeErrors: false };
    $('quote-form').reset();
    ['err-date', 'err-airports', 'err-name', 'err-email'].forEach(function (id) { setError(id, ''); });
    ['travel-date', 'lead-name', 'lead-email'].forEach(function (id) { $(id).removeAttribute('aria-invalid'); });
    syncAirports();
    renderRooms();
    showForm();
  }

  /* ---------- wire up ---------- */
  buildAirports();
  syncAirports();
  renderRooms();

  $('more-airports').addEventListener('click', showMoreAirports);
  $('travel-date').addEventListener('change', function (e) {
    if (e.target.value) setError('err-date', '', e.target);
    renderRooms();
  });
  $('bedrooms').addEventListener('change', function (e) {
    state.roomCount = Number(e.target.value);
    renderRooms();
  });
  $('lead-name').addEventListener('input', function (e) { if (e.target.value.trim()) setError('err-name', '', e.target); });
  $('lead-email').addEventListener('input', function (e) { if ($('err-email').hidden === false && /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(e.target.value.trim())) setError('err-email', '', e.target); });
  $('quote-form').addEventListener('submit', function (e) {
    e.preventDefault();
    var first = validate();
    if (first) {
      first.focus();
      if (first.scrollIntoView) first.scrollIntoView({ block: 'center' });
      return;
    }
    showDone();
  });
  $('edit-details').addEventListener('click', function () { showForm(); $('travel-date').focus(); });
  $('start-again').addEventListener('click', function () { reset(); $('travel-date').focus(); });
})();
